require 'spec_helper'

describe MoviesController do

  describe 'searching TMDb' do
    it 'should do some test here' do
      flunk "this test is not yet implemented"
    end
  end

#   Movie.create (movie stuff)

end
