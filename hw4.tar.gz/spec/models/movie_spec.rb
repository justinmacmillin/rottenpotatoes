require 'spec_helper'

describe Movie do
  pending "add some examples to (or delete) #{__FILE__}"
end
