# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rottenpotatoes::Application.config.secret_token = 'fc0f0954076412701f7ec79f6174c1f5ce78bb75d2d01bf9e9108c4549db0b294b719446a9a4a93652e1966c00f32ac8b0571ee8f50472336f4b35d66e0effee'
